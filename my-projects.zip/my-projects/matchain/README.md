# Matchain
Matchain BOT
Inspired by [@adearman](https://github.com/adearman) & [@akasaid](https://github.com/akasakaid)

## Registration
Link : (https://t.me/MatchQuestBot/start?startapp=f3dd36705c51ba3300a606c1f9901d24)

## Installation

Install with python

  1. Download Python 3.10+
  2. Install Module
  ```
   python -m pip install -r requirements.txt
   ```
  3. Buka Bot Matchain di PC (Telegram Desktop)
  4. Inspect Element > Application > Session Storage > Pilih Matchain > Ambil tgWebAppData
  5. Klik kanan lalu copy value (query_id=xxxx atau user=xx) paste di initdata.txt
  6. python3 matchain.py (Whatever gimana cara manggil pythonnya)

Contact : (https://t.me/n_bayhaqi)

## Screenshot
![App Screenshot](https://i.ibb.co.com/PQQKKVD/1111.jpg)
