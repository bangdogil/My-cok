
# CyberFinance
CyberFinance Bot . Subscribe my github and also give stars if you like this tool :) 

Register Here : [CyberFinance](https://t.me/CyberFinanceBot?start=cj1qUmJnQjJYMmlYRlYmdT1yZWY=)

## Installation

Install with python

1. Download Python 3.10+
2. Install Module (pip install requests colorama)
3. Buka Bot CFI di PC (Telegram Desktop)
4. Jika sudah terbuka > Klik kanan Inspect
5. Pergi ke application > session storage
6. ___Telegram_initparams
7. Ambil tgwebappdata. Save di initdata.txt
8. python cfi.py


## Features
- Auto Upgrade Hammer
- Auto Upgrade Egg
- Auto Claim 
- Auto Clear Task
- Auto Refresh Token
- Add Limit Upgrade
- Multi Account

## Screenshots

![App Screenshot](https://i.ibb.co.com/Hxxrhjm/Cuplikan-layar-2024-06-21-211454.png)


## Contributor

Telegram @fahmiiuii
