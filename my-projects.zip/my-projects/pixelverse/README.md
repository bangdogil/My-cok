<h1 align="center">Auto Reff Pixelverse ( DWYOR )</h1>
<h3 align="center">Tutorial How To Use This Bot</h3>

- https://dashboard.pixelverse.xyz/ Register

- git clone **https://github.com/monteksz/pixelverse**

- cd pixelverse

- pip install -r requirements.txt

- python main.py

- Set Your Refferal Code

- Set How Many Reff Do You Want

- **Here To get reff code**
<img align="center" src="https://github.com/monteksz/PixelTap/blob/main/d.png">

<h3 align="left">Languages</h3>
<p align="left"> <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> </p>
