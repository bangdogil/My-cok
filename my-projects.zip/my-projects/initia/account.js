const account = [["WALLET ADDRESS", "PRIVATE KEY"]];

export { account };
