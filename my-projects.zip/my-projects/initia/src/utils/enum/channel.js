export const CHANNEL = {
  USDC: "channel-13",
  TIA: "channel-31",
  TUCANA: "channel-25",
  ETH: "channel-0",
};
